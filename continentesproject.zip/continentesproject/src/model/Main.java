package model;

import model.Continente;
import model.Pais;

public class Main {
    public static void main(String[] args) {
       
        Pais brasil = new Pais("BRA", "Brasil", 8515767.049);
        brasil.setPopulacao(213317639);

        Pais argentina = new Pais("ARG", "Argentina", 2780400);
        argentina.setPopulacao(45604580);

        Pais uruguai = new Pais("URU", "Uruguai", 176215);
        uruguai.setPopulacao(3473730);

       
        brasil.adicionarFronteira(argentina);
        brasil.adicionarFronteira(uruguai);
        argentina.adicionarFronteira(uruguai);

        
        Continente americaDoSul = new Continente("América do Sul");
        americaDoSul.adicionarPais(brasil);
        americaDoSul.adicionarPais(argentina);
        americaDoSul.adicionarPais(uruguai);

       
        System.out.println(americaDoSul.exibirDetalhes());
        System.out.println("País com maior população: " + americaDoSul.obterPaisMaiorPopulacao().getNome());
        System.out.println("Razão territorial: " + americaDoSul.calcularRazaoTerritorial());
        System.out.println("Vizinhos comuns entre Brasil e Argentina: " +
            brasil.vizinhosComuns(argentina));
    }
}
