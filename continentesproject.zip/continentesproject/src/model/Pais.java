package model;

import java.util.ArrayList;
import java.util.List;

public class Pais {
    private String codigoISO;
    private String nome;
    private long populacao;
    private double dimensao;
    private List<Pais> fronteiras;


    public Pais(String codigoISO, String nome, double dimensao) {
        if (codigoISO == null || codigoISO.length() != 3) {
            throw new IllegalArgumentException("Código ISO deve ter exatamente 3 caracteres.");
        }
        this.codigoISO = codigoISO.toUpperCase();
        this.nome = nome;
        this.dimensao = dimensao;
        this.fronteiras = new ArrayList<>();
    }

   
    public String getCodigoISO() {
        return codigoISO;
    }

    public void setCodigoISO(String codigoISO) {
        this.codigoISO = codigoISO.toUpperCase();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public long getPopulacao() {
        return populacao;
    }

    public void setPopulacao(long populacao) {
        this.populacao = populacao;
    }

    public double getDimensao() {
        return dimensao;
    }

    public void setDimensao(double dimensao) {
        this.dimensao = dimensao;
    }

  
    public void adicionarFronteira(Pais pais) {
        if (pais == null || this.equals(pais)) {
            throw new IllegalArgumentException("Um país não pode ser fronteira de si mesmo.");
        }
        if (!this.fronteiras.contains(pais) && this.fronteiras.size() < 40) {
            this.fronteiras.add(pais);
            pais.adicionarFronteira(this);
        }
    }


    public boolean verificaIgualdade(Pais outroPais) {
        return this.codigoISO.equalsIgnoreCase(outroPais.codigoISO);
    }


    public boolean eLimitrofe(Pais outroPais) {
        return this.fronteiras.contains(outroPais);
    }

  
    public double calcularDensidadePopulacional() {
        return dimensao > 0 ? (double) populacao / dimensao : 0;
    }


    public List<Pais> vizinhosComuns(Pais outroPais) {
        List<Pais> vizinhosComuns = new ArrayList<>(this.fronteiras);
        vizinhosComuns.retainAll(outroPais.fronteiras);
        return vizinhosComuns;
    }

   
    public List<Pais> getFronteiras() {
        return fronteiras;
    }

  
    public String toString() {
        return String.format(
            "País: %s (%s)\nPopulação: %d\nDimensão: %.2f km²\nDensidade Populacional: %.2f hab/km²\n",
            nome, codigoISO, populacao, dimensao, calcularDensidadePopulacional()
        );
    }
}
