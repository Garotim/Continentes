package model;

import java.util.ArrayList;
import java.util.List;

public class Continente {
    private String nome;
    private List<Pais> paises;

    
    public Continente(String nome) {
        this.nome = nome;
        this.paises = new ArrayList<>();
    }

 
    public void adicionarPais(Pais pais) {
        if (pais == null || this.paises.contains(pais)) {
            throw new IllegalArgumentException("País já adicionado ou inválido.");
        }
        this.paises.add(pais);
    }

   
    public double calcularDimensaoTotal() {
        return paises.stream().mapToDouble(Pais::getDimensao).sum();
    }

   
    public long calcularPopulacaoTotal() {
        return paises.stream().mapToLong(Pais::getPopulacao).sum();
    }

   
    public double calcularDensidadePopulacional() {
        double dimensaoTotal = calcularDimensaoTotal();
        return dimensaoTotal > 0 ? calcularPopulacaoTotal() / dimensaoTotal : 0;
    }

 
    public Pais obterPaisMaiorPopulacao() {
        return paises.stream().max((p1, p2) -> Long.compare(p1.getPopulacao(), p2.getPopulacao())).orElse(null);
    }


    public Pais obterPaisMenorPopulacao() {
        return paises.stream().min((p1, p2) -> Long.compare(p1.getPopulacao(), p2.getPopulacao())).orElse(null);
    }

   
    public Pais obterPaisMaiorDimensao() {
        return paises.stream().max((p1, p2) -> Double.compare(p1.getDimensao(), p2.getDimensao())).orElse(null);
    }

  
    public Pais obterPaisMenorDimensao() {
        return paises.stream().min((p1, p2) -> Double.compare(p1.getDimensao(), p2.getDimensao())).orElse(null);
    }

  
    public double calcularRazaoTerritorial() {
        Pais maior = obterPaisMaiorDimensao();
        Pais menor = obterPaisMenorDimensao();
        if (maior != null && menor != null) {
            return maior.getDimensao() / menor.getDimensao();
        }
        return 0;
    }


    public String exibirDetalhes() {
        return String.format(
            "Continente: %s\nPopulação Total: %d\nDimensão Total: %.2f km²\nDensidade Populacional: %.2f hab/km²\n",
            nome, calcularPopulacaoTotal(), calcularDimensaoTotal(), calcularDensidadePopulacional()
        );
    }
}
